(function(window, undefined) {
  var dictionary = {
    "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145": "GestorClientes",
    "bda84b32-7beb-4df8-ade7-f07e1f2a1ce0": "GestorProveedores",
    "a6c98bb6-7e30-4b20-ba01-c4320b787530": "Settings",
    "83bd22f7-bb08-4ca5-9726-db4883c3b9d7": "GestorFacturas",
    "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a": "Main",
    "0bb10460-ea73-4f86-8d97-cc04ab9b7761": "GestorPersonal",
    "0e0d9f7e-05db-4465-9a6b-c5f5a70cd80f": "TurnOff",
    "ae9fff32-a68c-40c1-97d4-c2cc747b36be": "GestorStock",
    "dc777be1-be6e-48b3-8508-b71f3161aeb2": "GestorReparaciones",
    "300b70c1-5008-4e72-9915-d9b948938096": "Finish",
    "76bbee1e-bae9-4323-af44-3518353e54fa": "MainEmpleado",
    "eb7a9d2c-f07c-4537-9f05-6594a52655cf": "GestorProveedores2",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Intro",
    "281812be-1d21-4c78-8422-df261efa9963": "GestorFacturas2",
    "3e7d3062-0644-41af-88f4-71de5ef19cef": "Gestor Balance",
    "0b4e0db8-67d4-494e-9e94-ecfc28c639ae": "GestorServicios",
    "87db3cf7-6bd4-40c3-b29c-45680fb11462": "960 grid - 16 columns",
    "e5f958a4-53ae-426e-8c05-2f7d8e00b762": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);