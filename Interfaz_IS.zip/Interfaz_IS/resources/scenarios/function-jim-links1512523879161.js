(function(window, undefined) {

  var jimLinks = {
    "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "bda84b32-7beb-4df8-ade7-f07e1f2a1ce0" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "a6c98bb6-7e30-4b20-ba01-c4320b787530" : {
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Text_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Image_1" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "83bd22f7-bb08-4ca5-9726-db4883c3b9d7" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a" : {
      "Image_2" : [
        "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145"
      ],
      "Text_2" : [
        "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145"
      ],
      "Image_3" : [
        "83bd22f7-bb08-4ca5-9726-db4883c3b9d7"
      ],
      "Image_4" : [
        "ae9fff32-a68c-40c1-97d4-c2cc747b36be"
      ],
      "Image_5" : [
        "dc777be1-be6e-48b3-8508-b71f3161aeb2"
      ],
      "Image_8" : [
        "0bb10460-ea73-4f86-8d97-cc04ab9b7761"
      ],
      "Image_9" : [
        "0b4e0db8-67d4-494e-9e94-ecfc28c639ae"
      ],
      "Text_9" : [
        "0b4e0db8-67d4-494e-9e94-ecfc28c639ae"
      ],
      "Image_10" : [
        "3e7d3062-0644-41af-88f4-71de5ef19cef"
      ],
      "Image_11" : [
        "bda84b32-7beb-4df8-ade7-f07e1f2a1ce0"
      ],
      "Text_13" : [
        "0bb10460-ea73-4f86-8d97-cc04ab9b7761"
      ],
      "Text_14" : [
        "3e7d3062-0644-41af-88f4-71de5ef19cef"
      ],
      "Text_8" : [
        "83bd22f7-bb08-4ca5-9726-db4883c3b9d7"
      ],
      "Text_12" : [
        "ae9fff32-a68c-40c1-97d4-c2cc747b36be"
      ],
      "Text_15" : [
        "bda84b32-7beb-4df8-ade7-f07e1f2a1ce0"
      ],
      "Text_16" : [
        "dc777be1-be6e-48b3-8508-b71f3161aeb2"
      ],
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ]
    },
    "0bb10460-ea73-4f86-8d97-cc04ab9b7761" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_5" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "ae9fff32-a68c-40c1-97d4-c2cc747b36be" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "dc777be1-be6e-48b3-8508-b71f3161aeb2" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "300b70c1-5008-4e72-9915-d9b948938096" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_3" : [
        "0e0d9f7e-05db-4465-9a6b-c5f5a70cd80f"
      ],
      "Text_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Image_1" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "76bbee1e-bae9-4323-af44-3518353e54fa" : {
      "Image_2" : [
        "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145"
      ],
      "Text_2" : [
        "9d70c8fd-a685-4b7c-9e8e-1f2ac9f21145"
      ],
      "Image_3" : [
        "83bd22f7-bb08-4ca5-9726-db4883c3b9d7"
      ],
      "Image_4" : [
        "ae9fff32-a68c-40c1-97d4-c2cc747b36be"
      ],
      "Image_5" : [
        "dc777be1-be6e-48b3-8508-b71f3161aeb2"
      ],
      "Text_8" : [
        "83bd22f7-bb08-4ca5-9726-db4883c3b9d7"
      ],
      "Text_12" : [
        "ae9fff32-a68c-40c1-97d4-c2cc747b36be"
      ],
      "Text_16" : [
        "dc777be1-be6e-48b3-8508-b71f3161aeb2"
      ],
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ]
    },
    "eb7a9d2c-f07c-4537-9f05-6594a52655cf" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "bda84b32-7beb-4df8-ade7-f07e1f2a1ce0"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "281812be-1d21-4c78-8422-df261efa9963" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "83bd22f7-bb08-4ca5-9726-db4883c3b9d7"
      ]
    },
    "3e7d3062-0644-41af-88f4-71de5ef19cef" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_5" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    },
    "0b4e0db8-67d4-494e-9e94-ecfc28c639ae" : {
      "Image_12" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Image_13" : [
        "300b70c1-5008-4e72-9915-d9b948938096"
      ],
      "Text_17" : [
        "a6c98bb6-7e30-4b20-ba01-c4320b787530"
      ],
      "Text_10" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_2" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_3" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_4" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ],
      "Button_5" : [
        "7c2e4f9e-004e-4a2c-b69c-8cb00678f97a"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);